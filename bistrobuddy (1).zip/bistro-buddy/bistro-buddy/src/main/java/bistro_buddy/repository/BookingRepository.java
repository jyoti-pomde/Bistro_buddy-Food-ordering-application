package bistro_buddy.repository;
import bistro_buddy.model.Booking;


import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
}