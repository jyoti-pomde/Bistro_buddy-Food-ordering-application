package bistro_buddy.repository;

import bistro_buddy.entity.TableBooking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TableBookingRepository extends JpaRepository<TableBooking, Long> {
}