package bistro_buddy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import bistro_buddy.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}