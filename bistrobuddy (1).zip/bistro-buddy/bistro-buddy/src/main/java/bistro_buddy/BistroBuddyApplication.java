package bistro_buddy;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "bistro_buddy")
public class BistroBuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BistroBuddyApplication.class, args);
	}

}
