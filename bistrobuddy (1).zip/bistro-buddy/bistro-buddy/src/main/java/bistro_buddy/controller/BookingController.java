package bistro_buddy.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import bistro_buddy.model.Booking;
import bistro_buddy.repository.BookingRepository;
import jakarta.annotation.PostConstruct;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/booking")
public class BookingController {

    @Autowired
    private BookingRepository repo;
    
    @PostConstruct
    public void init() {
    	System.out.println("Booking Controller loaded");
    }

    @PostMapping
    public Booking createBooking(@RequestBody Booking booking) {
        return repo.save(booking);
    }

    @GetMapping
    public List<Booking> getAllBookings() {
        return repo.findAll();
    }
}