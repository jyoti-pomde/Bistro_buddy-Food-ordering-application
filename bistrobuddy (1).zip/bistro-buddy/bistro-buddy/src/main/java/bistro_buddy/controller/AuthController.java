package bistro_buddy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import bistro_buddy.entity.User;
import bistro_buddy.repository.UserRepository;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserRepository repo;
    
    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return repo.save(user);
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> req) {

        String username = req.get("username");
        String password = req.get("password");

        User user = repo.findByUsername(username);

        Map<String, String> res = new HashMap<>();

        if (user != null && user.getPassword().equals(password)) {
            res.put("status", "success");
            res.put("role", user.getRole());
        } else {
            res.put("status", "failed");
        }

        return res;
    }
}