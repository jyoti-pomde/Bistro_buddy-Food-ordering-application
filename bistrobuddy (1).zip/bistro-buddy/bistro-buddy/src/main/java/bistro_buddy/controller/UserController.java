package bistro_buddy.controller;


import bistro_buddy.entity.User;
import bistro_buddy.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public User register(@RequestBody User user) {
        return userService.saveUser(user);
    }
}