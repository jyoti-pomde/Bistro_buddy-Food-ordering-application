package bistro_buddy.controller;

import bistro_buddy.entity.TableBooking;
import bistro_buddy.service.TableBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/tables")
public class TableBookingController {

    @Autowired
    private TableBookingService service;

    @PostMapping
    public TableBooking book(@RequestBody TableBooking booking) {
        return service.bookTable(booking);
    }

    @GetMapping
    public List<TableBooking> getBookings() {
        return service.getAllBookings();
    }
}