package bistro_buddy.controller;

import bistro_buddy.entity.Orders;
import bistro_buddy.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/orders")
public class OrdersController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public Orders placeOrder(@RequestBody Orders order) {
        return orderService.placeOrder(order);
    }

    @GetMapping
    public List<Orders> getOrders() {
        return orderService.getAllOrders();
    }
}