package bistro_buddy.controller;

import bistro_buddy.entity.Menu;
import bistro_buddy.service.MenuService;
import jakarta.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;
    
    @PostConstruct
    public void init() {
    	System.out.println("Menucontroller loaded");
    }

    @PostMapping
    public Menu addMenu(@RequestBody Menu menu) {
        return menuService.addMenu(menu);
    }

    @GetMapping
    public List<Menu> getMenu() {
        return menuService.getAllMenu();
    }
}