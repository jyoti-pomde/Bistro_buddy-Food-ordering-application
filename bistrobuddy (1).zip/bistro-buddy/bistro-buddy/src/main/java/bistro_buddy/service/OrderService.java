package bistro_buddy.service;

import bistro_buddy.entity.Orders;
import bistro_buddy.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public Orders placeOrder(Orders order) {
        order.setTotal(order.getPrice() * order.getQuantity());
        return orderRepository.save(order);
    }

    public List<Orders> getAllOrders() {
        return orderRepository.findAll();
    }
}