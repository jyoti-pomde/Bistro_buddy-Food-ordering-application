package bistro_buddy.service;

import bistro_buddy.entity.Menu;
import bistro_buddy.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {

    @Autowired
    private MenuRepository menuRepository;

    public Menu addMenu(Menu menu) {
    	System.out.println("Service hit");
        return menuRepository.save(menu);
    }

    public List<Menu> getAllMenu() {
        return menuRepository.findAll();
    }
}