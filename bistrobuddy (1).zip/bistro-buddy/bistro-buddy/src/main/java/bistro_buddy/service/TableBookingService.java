package bistro_buddy.service;

import bistro_buddy.entity.TableBooking;
import bistro_buddy.repository.TableBookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TableBookingService {

    @Autowired
    private TableBookingRepository repository;

    public TableBooking bookTable(TableBooking booking) {
        booking.setStatus("BOOKED");
        return repository.save(booking);
    }

    public List<TableBooking> getAllBookings() {
        return repository.findAll();
    }
}