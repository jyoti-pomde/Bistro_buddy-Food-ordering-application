package bistro_buddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BistroBuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
